i = '4';
a = [1,3,3];
csvwrite('aaa.csv' + i,a);